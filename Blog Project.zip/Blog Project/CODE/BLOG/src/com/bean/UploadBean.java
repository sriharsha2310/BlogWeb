package com.bean;


public class UploadBean {
	private String filedata,fid,uid,da;
	public String getDa() {
		return da;
	}

	public void setDa(String da) {
		this.da = da;
	}

	public String getFid() {
		return fid;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getFiledata() {
		return filedata;
	}

	public void setFiledata(String filedata) {
		this.filedata = filedata;
	}

	public void setFid(String fid) {
		this.fid = fid;
	}

	
}
